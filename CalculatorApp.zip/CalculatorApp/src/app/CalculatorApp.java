package app;

import java.util.Scanner;

public class CalculatorApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculator calc = new Calculator();

        System.out.print("İlk sayıyı gir: ");
        double n1 = scanner.nextDouble();

        System.out.print("İkinci sayıyı gir: ");
        double n2 = scanner.nextDouble();

        System.out.println("1- Toplama");
        System.out.println("2- Çıkarma");
        System.out.println("3- Çarpma");
        System.out.println("4- Bölme");
        System.out.print("Seçim yap: ");
        int secim = scanner.nextInt();

        double sonuc = 0;

        switch(secim) {
            case 1: sonuc = calc.add(n1, n2); break;
            case 2: sonuc = calc.subtract(n1, n2); break;
            case 3: sonuc = calc.multiply(n1, n2); break;
            case 4: sonuc = calc.divide(n1, n2); break;
        }

        System.out.println("Sonuç = " + sonuc);
        scanner.close();
    }
}
