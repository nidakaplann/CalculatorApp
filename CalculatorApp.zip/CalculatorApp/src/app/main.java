package app;

import java.util.Scanner;


public class main {

	public static void main(String[] args) {
		
		        Scanner sc = new Scanner(System.in);
		        Calculator calc = new Calculator();

		        while (true) {
		            System.out.println("\n=== Hesap Makinesi ===");
		            System.out.println("1- Toplama");
		            System.out.println("2- Çıkarma");
		            System.out.println("3- Çarpma");
		            System.out.println("4- Bölme");
		            System.out.println("0- Çıkış");
		            System.out.print("Seçim: ");

		            int secim = sc.nextInt();

		            if (secim == 0) {
		                System.out.println("Programdan çıkılıyor...");
		                break;
		            }

		            System.out.print("1. Sayı: ");
		            double s1 = sc.nextDouble();
		            System.out.print("2. Sayı: ");
		            double s2 = sc.nextDouble();

		            try {
		                switch (secim) {
		                    case 1 -> System.out.println("Sonuç: " + calc.add(s1, s2));
		                    case 2 -> System.out.println("Sonuç: " + calc.subtract(s1, s2));
		                    case 3 -> System.out.println("Sonuç: " + calc.multiply(s1, s2));
		                    case 4 -> System.out.println("Sonuç: " + calc.divide(s1, s2));
		                    default -> System.out.println("Geçersiz seçim!");
		                }
		            } catch (Exception e) {
		                System.out.println(e.getMessage());
		            }
		        }
		        sc.close();
		    }

	}

